#pragma once
#include <string>
using namespace std;
class Hint
{
public:
	// A switch sttement for giving hints
	string giveHint(int&);
};

