#include "fileLog.h"
int main()
{

	fileLog("This is a log message");

	return 0;
}