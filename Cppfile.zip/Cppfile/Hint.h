#pragma once
#include <string>
using namespace std;
class Hint
{
public:
	string giveHint(int&);
};

